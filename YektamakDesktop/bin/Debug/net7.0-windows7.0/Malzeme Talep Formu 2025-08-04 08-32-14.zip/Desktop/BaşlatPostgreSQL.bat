cd "C:\Program Files\PostgreSQL\16\bin"
pg_ctl start -D "C:\Program Files\PostgreSql\16\data"